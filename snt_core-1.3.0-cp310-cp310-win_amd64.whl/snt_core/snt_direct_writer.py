"""
Protected direct SNT -> SNT writer.

Design goals
------------
* Never generate DXF during normal Save.
* Copy unchanged native entity records byte-for-byte.
* Re-encode only added or explicitly updated entities.
* Support add/delete/move plus layer add/rename/update/delete.
* Preserve META and BLOCKS bytes exactly unless metadata_updates is supplied.
* Rebuild INDEX, offsets, global bbox and header CRC.
* Validate the temporary SNT with SntReader before atomic replacement.

This module intentionally imports the format constants from the same snt_core
package. When compiled into the protected wheel it therefore uses the exact
format contract of that wheel rather than duplicating or guessing constants.
"""
from __future__ import annotations

import json
import math
import mmap
import os
import shutil
import struct
import tempfile
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, MutableMapping, Optional, Sequence, Tuple

from .snt_format import (
    ENTITY_HDR_FMT,
    ENTITY_HDR_SIZE,
    FLAG_HAS_BLOCKS,
    FLAG_HAS_CRS,
    FLAG_HAS_INDEX,
    FLAG_USE_F64,
    HEADER_CRC_END,
    HEADER_CRC_OFFSET,
    HEADER_FMT,
    HEADER_SIZE,
    INDEX_FMT,
    INDEX_SIZE,
    LAYER_FMT,
    LAYER_SIZE,
    META_SIZE_FMT,
    SNT_MAGIC,
    ColorMode,
    EntityType,
    validate_format_constants,
)
from .snt_reader import CorruptFileError, SntReader

validate_format_constants()


class DirectWriteError(RuntimeError):
    """Raised when a direct SNT edit cannot be completed safely."""


@dataclass(frozen=True)
class DirectWriteResult:
    snt_path: Path
    original_entity_count: int
    entity_count: int
    added_count: int
    deleted_count: int
    updated_count: int
    moved_count: int
    layer_count: int
    source_size_bytes: int
    output_size_bytes: int
    unchanged_records_copied: int


@dataclass(frozen=True)
class _Header:
    magic: int
    version_major: int
    version_minor: int
    flags: int
    entity_count: int
    bbox: Tuple[float, float, float, float]
    off_meta: int
    off_strings: int
    off_layers: int
    off_blocks: int
    off_entities: int
    off_index: int
    reserved: bytes


@dataclass(frozen=True)
class _Layer:
    name_idx: int
    color_aci: int
    linetype_idx: int
    flags: int
    raw: bytes


@dataclass(frozen=True)
class _EncodedEntity:
    record: bytes
    bbox: Tuple[float, float, float, float]


def _parse_header(mm_obj: mmap.mmap) -> _Header:
    if len(mm_obj) < HEADER_SIZE:
        raise DirectWriteError("SNT is smaller than the fixed header.")
    raw = bytes(mm_obj[:HEADER_SIZE])
    values = struct.unpack_from(HEADER_FMT, raw)
    (
        magic,
        vmaj,
        vmin,
        flags,
        entity_count,
        xmin,
        ymin,
        xmax,
        ymax,
        off_meta,
        off_strings,
        off_layers,
        off_blocks,
        off_entities,
        off_index,
        stored_crc,
        _reserved,
    ) = values
    if magic != SNT_MAGIC:
        raise DirectWriteError(
            f"Invalid SNT magic 0x{magic:08X}; expected 0x{SNT_MAGIC:08X}."
        )
    computed_crc = zlib.crc32(raw[:HEADER_CRC_OFFSET]) & 0xFFFF_FFFF
    if computed_crc != stored_crc:
        raise DirectWriteError(
            f"Header CRC mismatch: stored=0x{stored_crc:08X}, "
            f"computed=0x{computed_crc:08X}."
        )
    file_size = len(mm_obj)
    required = [off_meta, off_strings, off_layers, off_blocks, off_entities]
    if any(int(x) < HEADER_SIZE or int(x) > file_size for x in required):
        raise DirectWriteError("One or more SNT block offsets are outside the file.")
    if not (off_meta <= off_strings <= off_layers <= off_blocks <= off_entities):
        raise DirectWriteError("SNT block offsets are out of order.")
    if flags & FLAG_HAS_INDEX:
        if not (off_entities <= off_index <= file_size):
            raise DirectWriteError("SNT INDEX offset is outside the file.")
    else:
        off_index = file_size
    return _Header(
        magic=int(magic),
        version_major=int(vmaj),
        version_minor=int(vmin),
        flags=int(flags),
        entity_count=int(entity_count),
        bbox=(float(xmin), float(ymin), float(xmax), float(ymax)),
        off_meta=int(off_meta),
        off_strings=int(off_strings),
        off_layers=int(off_layers),
        off_blocks=int(off_blocks),
        off_entities=int(off_entities),
        off_index=int(off_index),
        reserved=bytes(_reserved),
    )


def _read_string_pool(block: bytes) -> list[str]:
    if len(block) < 4:
        raise DirectWriteError("STRINGS block is truncated.")
    count = struct.unpack_from("<I", block, 0)[0]
    pos = 4
    result: list[str] = []
    for i in range(int(count)):
        if pos + 2 > len(block):
            raise DirectWriteError(f"STRINGS block truncated at entry {i} length.")
        length = struct.unpack_from("<H", block, pos)[0]
        pos += 2
        if pos + length > len(block):
            raise DirectWriteError(f"STRINGS block truncated at entry {i} bytes.")
        result.append(block[pos : pos + length].decode("utf-8", errors="replace"))
        pos += length
    # There should normally be no trailing bytes, but preserving old entries in
    # order is more important than rejecting a harmless future extension.
    return result


def _serialize_string_pool(strings: Sequence[str]) -> bytes:
    parts: list[bytes] = [struct.pack("<I", len(strings))]
    for value in strings:
        raw = str(value).encode("utf-8")
        if len(raw) > 0xFFFF:
            raise DirectWriteError(
                f"String exceeds the SNT uint16 limit ({len(raw)} bytes)."
            )
        parts.append(struct.pack("<H", len(raw)))
        parts.append(raw)
    return b"".join(parts)


def _unpack_layer_record(raw: bytes) -> _Layer:
    if len(raw) != LAYER_SIZE:
        raise DirectWriteError("Invalid layer record size.")
    values = struct.unpack(LAYER_FMT, raw)
    # Known compatible format families used by SNT v1.x.
    if LAYER_FMT == "<IHIBB" and len(values) == 5:
        name_idx, color_aci, linetype_idx, flags, _reserved = values
    elif LAYER_FMT == "<IHHBBH" and len(values) == 6:
        name_idx, color_aci, linetype_idx, flags, _reserved8, _reserved16 = values
    else:
        # Fallback for a format with the same public semantic prefix. This is
        # intentionally strict; silently guessing a proprietary record layout
        # would risk corrupting every layer reference.
        raise DirectWriteError(
            f"Unsupported LAYER_FMT {LAYER_FMT!r}; direct writer must be rebuilt "
            "against the matching snt_core format source."
        )
    return _Layer(
        name_idx=int(name_idx),
        color_aci=int(color_aci),
        linetype_idx=int(linetype_idx),
        flags=int(flags),
        raw=raw,
    )


def _pack_layer_record(name_idx: int, color_aci: int, linetype_idx: int, flags: int) -> bytes:
    if LAYER_FMT == "<IHIBB":
        return struct.pack(
            LAYER_FMT,
            int(name_idx),
            int(color_aci) & 0xFFFF,
            int(linetype_idx),
            int(flags) & 0xFF,
            0,
        )
    if LAYER_FMT == "<IHHBBH":
        if int(linetype_idx) > 0xFFFF:
            raise DirectWriteError(
                "Linetype string index exceeds the uint16 limit of this SNT layer format."
            )
        return struct.pack(
            LAYER_FMT,
            int(name_idx),
            int(color_aci) & 0xFFFF,
            int(linetype_idx) & 0xFFFF,
            int(flags) & 0xFF,
            0,
            0,
        )
    raise DirectWriteError(f"Unsupported LAYER_FMT {LAYER_FMT!r}.")


def _read_layers(mm_obj: mmap.mmap, header: _Header) -> list[_Layer]:
    span = header.off_blocks - header.off_layers
    if span < 0 or span % LAYER_SIZE:
        raise DirectWriteError(
            f"LAYERS block size {span} is not divisible by LAYER_SIZE={LAYER_SIZE}."
        )
    layers: list[_Layer] = []
    pos = header.off_layers
    while pos < header.off_blocks:
        layers.append(_unpack_layer_record(bytes(mm_obj[pos : pos + LAYER_SIZE])))
        pos += LAYER_SIZE
    return layers


def _merge_metadata(meta_block: bytes, updates: Mapping[str, Any]) -> bytes:
    """Merge metadata only when explicitly requested; otherwise caller copies raw bytes."""
    if not updates:
        return meta_block
    if len(meta_block) < 4:
        raise DirectWriteError("META block is truncated.")
    comp_size = struct.unpack_from(META_SIZE_FMT, meta_block, 0)[0]
    payload = meta_block[4 : 4 + comp_size]
    if len(payload) != comp_size:
        raise DirectWriteError("META compressed payload is truncated.")

    # zstd frame magic bytes: 28 B5 2F FD
    uses_zstd = payload.startswith(b"\x28\xB5\x2F\xFD")
    if uses_zstd:
        try:
            import zstandard as zstd  # type: ignore
        except ImportError as exc:
            raise DirectWriteError(
                "Metadata uses zstd; install zstandard before changing META. "
                "Unmodified metadata can still be preserved byte-for-byte."
            ) from exc
        raw = zstd.ZstdDecompressor().decompress(payload)
    else:
        raw = zlib.decompress(payload)

    meta = json.loads(raw.decode("utf-8"))
    if not isinstance(meta, dict):
        raise DirectWriteError("META JSON root is not an object.")

    # Explicit EPSG fields are merged into both top-level and CRS map only when
    # provided. This preserves existing epsg_code/epsg_guess by default.
    for key, value in updates.items():
        if key == "crs" and isinstance(value, Mapping):
            current = meta.get("crs")
            if not isinstance(current, dict):
                current = {}
            current.update(dict(value))
            meta["crs"] = current
        else:
            meta[key] = value

    raw_new = json.dumps(meta, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if uses_zstd:
        payload_new = zstd.ZstdCompressor(level=3).compress(raw_new)
    else:
        payload_new = zlib.compress(raw_new, level=3)
    return struct.pack(META_SIZE_FMT, len(payload_new)) + payload_new


def _normalize_point(value: Any) -> Tuple[float, float, float]:
    if value is None:
        return (0.0, 0.0, 0.0)
    if len(value) < 2:
        raise DirectWriteError(f"Invalid point {value!r}.")
    return (
        float(value[0]),
        float(value[1]),
        float(value[2]) if len(value) > 2 else 0.0,
    )


def _entity_type_from_value(value: Any) -> EntityType:
    if isinstance(value, EntityType):
        return value
    if isinstance(value, int):
        try:
            return EntityType(value)
        except ValueError as exc:
            raise DirectWriteError(f"Unknown SNT entity type code {value}.") from exc
    name = str(value or "").strip().upper()
    aliases = {
        "3DFACE": "FACE3D",
        "FACE": "FACE3D",
        "POLYGON": "POLYLINE",
    }
    name = aliases.get(name, name)
    try:
        return EntityType[name]
    except KeyError as exc:
        raise DirectWriteError(f"Unsupported entity type {value!r} for direct write.") from exc


def _color_fields(entity: Mapping[str, Any]) -> Tuple[ColorMode, int]:
    raw_mode = entity.get("color_mode")
    raw_value = entity.get("color_value")
    if raw_mode is not None:
        try:
            mode = raw_mode if isinstance(raw_mode, ColorMode) else ColorMode(int(raw_mode))
        except Exception as exc:
            raise DirectWriteError(f"Invalid color_mode {raw_mode!r}.") from exc
        return mode, int(raw_value or 0)

    color = entity.get("color")
    if isinstance(color, (list, tuple)) and len(color) >= 3:
        vals = [float(color[0]), float(color[1]), float(color[2])]
        if max(abs(v) for v in vals) <= 1.0:
            vals = [v * 255.0 for v in vals]
        r, g, b = [max(0, min(255, int(round(v)))) for v in vals]
        return ColorMode.RGB, (r << 16) | (g << 8) | b
    return ColorMode.BYLAYER, 0


def _bbox_from_points(points: Sequence[Tuple[float, float, float]]) -> Tuple[float, float, float, float]:
    if not points:
        return (0.0, 0.0, 0.0, 0.0)
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return (min(xs), min(ys), max(xs), max(ys))


def _encode_entity(
    entity: Mapping[str, Any],
    layer_name_to_idx: Mapping[str, int],
    string_to_idx: MutableMapping[str, int],
    strings: list[str],
) -> _EncodedEntity:
    etype = _entity_type_from_value(entity.get("type") or entity.get("entity_type"))
    layer_name = str(entity.get("layer", "0") or "0")
    if layer_name not in layer_name_to_idx:
        raise DirectWriteError(f"Entity references missing layer {layer_name!r}.")
    layer_idx = int(layer_name_to_idx[layer_name])
    if layer_idx > 0xFFFF:
        raise DirectWriteError("SNT entity layer index exceeds uint16 capacity.")

    def str_idx(value: Any) -> int:
        text = str(value or "")
        existing = string_to_idx.get(text)
        if existing is not None:
            return int(existing)
        raw = text.encode("utf-8")
        if len(raw) > 0xFFFF:
            raise DirectWriteError("Entity string exceeds the SNT uint16 byte limit.")
        idx = len(strings)
        strings.append(text)
        string_to_idx[text] = idx
        return idx

    cmode, cval = _color_fields(entity)
    linetype_idx = str_idx(entity.get("linetype", "BYLAYER") or "BYLAYER")
    lineweight = int(entity.get("_lineweight", entity.get("lineweight", 0)) or 0)
    lineweight = max(0, min(255, lineweight))

    body: bytes
    bbox: Tuple[float, float, float, float]

    if etype == EntityType.POINT:
        p = _normalize_point(entity.get("position") or entity.get("location"))
        body = struct.pack("<3f", *p)
        bbox = (p[0], p[1], p[0], p[1])

    elif etype == EntityType.LINE:
        start = entity.get("start")
        end = entity.get("end")
        if start is None or end is None:
            pts_raw = entity.get("vertices") or entity.get("points") or []
            if len(pts_raw) < 2:
                raise DirectWriteError("LINE requires start/end or two vertices.")
            start, end = pts_raw[0], pts_raw[1]
        p0, p1 = _normalize_point(start), _normalize_point(end)
        body = struct.pack("<6f", *(p0 + p1))
        bbox = _bbox_from_points([p0, p1])

    elif etype == EntityType.ARC:
        center = _normalize_point(entity.get("center"))
        radius = float(entity.get("radius", 0.0))
        start_angle = float(entity.get("start_angle", 0.0))
        end_angle = float(entity.get("end_angle", 360.0))
        body = struct.pack("<6f", *center, radius, start_angle, end_angle)
        bbox = (
            center[0] - abs(radius),
            center[1] - abs(radius),
            center[0] + abs(radius),
            center[1] + abs(radius),
        )

    elif etype == EntityType.CIRCLE:
        center = _normalize_point(entity.get("center"))
        radius = float(entity.get("radius", 0.0))
        body = struct.pack("<4f", *center, radius)
        bbox = (
            center[0] - abs(radius),
            center[1] - abs(radius),
            center[0] + abs(radius),
            center[1] + abs(radius),
        )

    elif etype == EntityType.LWPOLYLINE:
        raw_points = entity.get("points") or entity.get("vertices") or []
        if not raw_points:
            raise DirectWriteError("LWPOLYLINE has no points.")
        points: list[Tuple[float, float, float]] = []
        bulges: list[float] = []
        for raw in raw_points:
            p = _normalize_point(raw)
            points.append(p)
            bulges.append(float(raw[3]) if len(raw) > 3 else 0.0)
        elevation = float(entity.get("elevation", points[0][2]))
        flags = int(entity.get("flags", 0)) & 0xFF
        if entity.get("closed"):
            flags |= 0x01
        chunks = [struct.pack("<fBI", elevation, flags, len(points))]
        for p, bulge in zip(points, bulges):
            chunks.append(struct.pack("<3f", p[0], p[1], bulge))
        body = b"".join(chunks)
        bbox = _bbox_from_points(points)

    elif etype == EntityType.POLYLINE:
        raw_points = entity.get("vertices") or entity.get("points") or []
        points = [_normalize_point(p) for p in raw_points]
        if not points:
            raise DirectWriteError("POLYLINE has no vertices.")
        flags = int(entity.get("flags", 0)) & 0xFF
        if entity.get("closed"):
            flags |= 0x01
        chunks = [struct.pack("<BI", flags, len(points))]
        chunks.extend(struct.pack("<3f", *p) for p in points)
        body = b"".join(chunks)
        bbox = _bbox_from_points(points)

    elif etype in (EntityType.TEXT, EntityType.MTEXT, EntityType.DIMENSION, EntityType.LEADER):
        p = _normalize_point(entity.get("position") or entity.get("insert"))
        height = float(entity.get("height", entity.get("char_height", 1.0)) or 1.0)
        rotation = float(entity.get("rotation", 0.0) or 0.0)
        text_idx = str_idx(entity.get("text", ""))
        style_idx = str_idx(entity.get("style", "STANDARD") or "STANDARD")
        body = struct.pack("<5fII", *p, height, rotation, text_idx, style_idx)
        bbox = (p[0], p[1], p[0], p[1])

    elif etype == EntityType.INSERT:
        p = _normalize_point(entity.get("position") or entity.get("insert"))
        sx = float(entity.get("xscale", 1.0) or 1.0)
        sy = float(entity.get("yscale", 1.0) or 1.0)
        sz = float(entity.get("zscale", 1.0) or 1.0)
        rotation = float(entity.get("rotation", 0.0) or 0.0)
        name_idx = str_idx(entity.get("name", entity.get("block_name", "")))
        body = struct.pack("<7fI", *p, sx, sy, sz, rotation, name_idx)
        bbox = (p[0], p[1], p[0], p[1])

    elif etype in (EntityType.SOLID, EntityType.FACE3D):
        raw_points = entity.get("vertices") or entity.get("points") or []
        points = [_normalize_point(p) for p in raw_points]
        if len(points) < 3:
            raise DirectWriteError(f"{etype.name} requires at least three vertices.")
        while len(points) < 4:
            points.append(points[-1])
        points = points[:4]
        body = struct.pack("<12f", *[c for p in points for c in p])
        bbox = _bbox_from_points(points)

    else:
        raise DirectWriteError(
            f"Direct encoding for {etype.name} is not implemented. "
            "Unchanged native records of this type are still copied losslessly."
        )

    header = struct.pack(
        ENTITY_HDR_FMT,
        int(etype),
        layer_idx,
        int(cmode),
        int(cval) & 0xFFFF_FFFF,
        int(linetype_idx),
        lineweight,
        len(body),
    )
    if len(header) != ENTITY_HDR_SIZE:
        raise DirectWriteError("Packed entity header size does not match format constants.")
    return _EncodedEntity(record=header + body, bbox=bbox)


def _bbox_from_body(etype: EntityType, body: bytes) -> Tuple[float, float, float, float]:
    """Best-effort bbox fallback when the source SNT has no valid INDEX."""
    try:
        if etype == EntityType.POINT and len(body) >= 12:
            x, y, _z = struct.unpack_from("<3f", body)
            return (x, y, x, y)
        if etype == EntityType.LINE and len(body) >= 24:
            sx, sy, _sz, ex, ey, _ez = struct.unpack_from("<6f", body)
            return (min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
        if etype in (EntityType.ARC, EntityType.CIRCLE) and len(body) >= 16:
            cx, cy, _cz, radius = struct.unpack_from("<4f", body)
            radius = abs(radius)
            return (cx - radius, cy - radius, cx + radius, cy + radius)
        if etype == EntityType.LWPOLYLINE and len(body) >= 9:
            _elev, _flags, count = struct.unpack_from("<fBI", body)
            pts = []
            for i in range(int(count)):
                off = 9 + i * 12
                if off + 8 > len(body):
                    break
                x, y = struct.unpack_from("<2f", body, off)
                pts.append((x, y, 0.0))
            return _bbox_from_points(pts)
        if etype == EntityType.POLYLINE and len(body) >= 5:
            _flags, count = struct.unpack_from("<BI", body)
            pts = []
            for i in range(int(count)):
                off = 5 + i * 12
                if off + 12 > len(body):
                    break
                pts.append(tuple(struct.unpack_from("<3f", body, off)))
            return _bbox_from_points(pts)
        if etype in (
            EntityType.TEXT,
            EntityType.MTEXT,
            EntityType.INSERT,
            EntityType.DIMENSION,
            EntityType.LEADER,
        ) and len(body) >= 8:
            x, y = struct.unpack_from("<2f", body)
            return (x, y, x, y)
        if etype in (EntityType.SOLID, EntityType.FACE3D) and len(body) >= 48:
            pts = [tuple(struct.unpack_from("<3f", body, i * 12)) for i in range(4)]
            return _bbox_from_points(pts)
    except Exception:
        pass
    return (0.0, 0.0, 0.0, 0.0)


def _read_index_bbox(
    mm_obj: mmap.mmap,
    header: _Header,
    entity_id: int,
) -> Optional[Tuple[float, float, float, float]]:
    if not (header.flags & FLAG_HAS_INDEX):
        return None
    pos = header.off_index + entity_id * INDEX_SIZE
    if pos < header.off_index or pos + INDEX_SIZE > len(mm_obj):
        return None
    try:
        _eid, x0, y0, x1, y1, _file_offset = struct.unpack_from(INDEX_FMT, mm_obj, pos)
        return (float(x0), float(y0), float(x1), float(y1))
    except struct.error:
        return None


def _validate_id_set(values: Iterable[int], entity_count: int, label: str) -> set[int]:
    result: set[int] = set()
    for raw in values:
        value = int(raw)
        if value < 0 or value >= entity_count:
            raise DirectWriteError(
                f"{label} contains entity ID {value}, outside [0, {entity_count})."
            )
        result.add(value)
    return result


def direct_write(
    snt_path: os.PathLike[str] | str,
    *,
    added_entities: Optional[Sequence[Mapping[str, Any]]] = None,
    deleted_entity_ids: Optional[Iterable[int]] = None,
    moved_entities: Optional[Mapping[int, str]] = None,
    updated_entities: Optional[Mapping[int, Mapping[str, Any]]] = None,
    added_layers: Optional[Sequence[Mapping[str, Any]]] = None,
    renamed_layers: Optional[Mapping[str, str]] = None,
    updated_layers: Optional[Mapping[str, Mapping[str, Any]]] = None,
    recolored_layers: Optional[Mapping[str, Sequence[int]]] = None,
    deleted_layers: Optional[Iterable[str]] = None,
    metadata_updates: Optional[Mapping[str, Any]] = None,
    validate: bool | str = True,
) -> DirectWriteResult:
    """
    Apply changes directly to an existing SNT without generating DXF.

    Entity IDs are zero-based file-order IDs from the currently opened SNT.
    Unchanged entity header+body records are copied byte-for-byte. A moved
    entity changes only its layer index in the common header; its native body
    remains untouched. Deleting an entity skips that record. New or explicitly
    updated entities are encoded from the supplied dictionaries.
    """
    source = Path(snt_path)
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f"SNT file not found: {source}")

    added_entities = list(added_entities or [])
    moved_entities = {int(k): str(v) for k, v in dict(moved_entities or {}).items()}
    updated_entities = {int(k): dict(v) for k, v in dict(updated_entities or {}).items()}
    added_layers = [dict(x) for x in (added_layers or [])]
    renamed_layers = {str(k): str(v) for k, v in dict(renamed_layers or {}).items()}
    updated_layers = {str(k): dict(v) for k, v in dict(updated_layers or {}).items()}
    recolored_layers = {str(k): tuple(v) for k, v in dict(recolored_layers or {}).items()}
    deleted_layers_set = {str(x) for x in (deleted_layers or [])}
    metadata_updates = dict(metadata_updates or {})

    source_size = source.stat().st_size
    temp_index_path: Optional[str] = None
    temp_output_path: Optional[str] = None

    with open(source, "rb") as src_file, mmap.mmap(src_file.fileno(), 0, access=mmap.ACCESS_READ) as mm_obj:
        header = _parse_header(mm_obj)

        no_changes = not any((
            added_entities,
            deleted_entity_ids,
            moved_entities,
            updated_entities,
            added_layers,
            renamed_layers,
            updated_layers,
            recolored_layers,
            deleted_layers,
            metadata_updates,
        ))
        if no_changes:
            # A repeated Save with no dirty changes must be truly O(1) and must
            # never rewrite a large SNT. Header parsing above already verifies
            # magic, CRC and block ordering. Optional full validation is retained
            # for regression tooling.
            if str(validate).lower() == "full":
                with SntReader(source) as verify_reader:
                    verified = 0
                    for verify_hdr in verify_reader.iter_entities():
                        verify_reader.read_body(verify_hdr)
                        verified += 1
                    if verified != header.entity_count:
                        raise DirectWriteError(
                            f"Full validation mismatch: expected {header.entity_count}, got {verified}."
                        )
            layer_span = header.off_blocks - header.off_layers
            if layer_span < 0 or layer_span % LAYER_SIZE:
                raise DirectWriteError(
                    f"LAYERS block size {layer_span} is not divisible by LAYER_SIZE={LAYER_SIZE}."
                )
            return DirectWriteResult(
                snt_path=source,
                original_entity_count=header.entity_count,
                entity_count=header.entity_count,
                added_count=0,
                deleted_count=0,
                updated_count=0,
                moved_count=0,
                layer_count=layer_span // LAYER_SIZE,
                source_size_bytes=source_size,
                output_size_bytes=source_size,
                unchanged_records_copied=header.entity_count,
            )

        if header.flags & FLAG_USE_F64:
            # The supplied v1.2 reader/reverse converter uses float32 body
            # layouts. Refuse to encode new geometry until matching f64 body
            # rules are available; unchanged records can still be copied.
            if added_entities or updated_entities:
                raise DirectWriteError(
                    "This SNT sets FLAG_USE_F64. Direct add/update requires the "
                    "matching float64 body specification; refusing to guess."
                )

        deleted_ids = _validate_id_set(
            deleted_entity_ids or [], header.entity_count, "deleted_entity_ids"
        )
        _validate_id_set(moved_entities.keys(), header.entity_count, "moved_entities")
        _validate_id_set(updated_entities.keys(), header.entity_count, "updated_entities")
        overlap = deleted_ids.intersection(updated_entities)
        if overlap:
            raise DirectWriteError(
                f"Entities cannot be both deleted and updated: {sorted(overlap)[:10]}"
            )

        meta_raw = bytes(mm_obj[header.off_meta : header.off_strings])
        strings_raw = bytes(mm_obj[header.off_strings : header.off_layers])
        blocks_raw = bytes(mm_obj[header.off_blocks : header.off_entities])
        strings = _read_string_pool(strings_raw)
        original_strings = list(strings)
        string_to_idx: Dict[str, int] = {}
        for idx, value in enumerate(strings):
            string_to_idx.setdefault(value, idx)

        def ensure_string(value: Any) -> int:
            text = str(value or "")
            idx = string_to_idx.get(text)
            if idx is not None:
                return int(idx)
            raw = text.encode("utf-8")
            if len(raw) > 0xFFFF:
                raise DirectWriteError(f"String {text[:40]!r} exceeds uint16 length.")
            idx = len(strings)
            strings.append(text)
            string_to_idx[text] = idx
            return idx

        original_layers = _read_layers(mm_obj, header)
        original_names: list[str] = []
        for layer in original_layers:
            if 0 <= layer.name_idx < len(strings):
                original_names.append(strings[layer.name_idx])
            else:
                raise DirectWriteError(
                    f"Layer name string index {layer.name_idx} is outside the pool."
                )

        # Build output layers while retaining original order whenever possible.
        output_layer_specs: list[Tuple[str, int, int, int]] = []
        original_idx_to_output_idx: Dict[int, int] = {}
        seen_names: set[str] = set()

        for original_idx, (layer, old_name) in enumerate(zip(original_layers, original_names)):
            if old_name in deleted_layers_set:
                continue
            new_name = renamed_layers.get(old_name, old_name).strip()
            if not new_name:
                raise DirectWriteError(f"Layer {old_name!r} was renamed to an empty name.")
            if new_name in seen_names:
                raise DirectWriteError(f"Duplicate output layer name {new_name!r}.")
            update = updated_layers.get(old_name, updated_layers.get(new_name, {}))
            color_aci = int(update.get("color_aci", layer.color_aci))
            linetype_name = update.get("linetype")
            if linetype_name is None:
                linetype_idx = layer.linetype_idx
            else:
                linetype_idx = ensure_string(linetype_name)
            flags = int(update.get("flags", layer.flags))
            output_idx = len(output_layer_specs)
            original_idx_to_output_idx[original_idx] = output_idx
            output_layer_specs.append((new_name, color_aci, int(linetype_idx), flags))
            seen_names.add(new_name)

        for layer in added_layers:
            name = str(layer.get("name", "") or "").strip()
            if not name:
                raise DirectWriteError("Added layer has an empty name.")
            if name in seen_names:
                # Treat duplicate add as update only if exact layer already exists.
                raise DirectWriteError(f"Added layer {name!r} already exists.")
            color_aci = int(layer.get("color_aci", layer.get("aci", 7)) or 7)
            linetype_idx = ensure_string(layer.get("linetype", "CONTINUOUS") or "CONTINUOUS")
            flags = int(layer.get("flags", 0) or 0)
            output_layer_specs.append((name, color_aci, linetype_idx, flags))
            seen_names.add(name)

        if not output_layer_specs:
            raise DirectWriteError("Direct write would produce an SNT with no layers.")

        # Layer name lookup accepts both renamed and final names.
        layer_name_to_idx: Dict[str, int] = {}
        for idx, (name, _aci, _lt, _flags) in enumerate(output_layer_specs):
            layer_name_to_idx[name] = idx
        for old_name, new_name in renamed_layers.items():
            if new_name in layer_name_to_idx:
                layer_name_to_idx[old_name] = layer_name_to_idx[new_name]

        for target_name in moved_entities.values():
            if target_name not in layer_name_to_idx:
                raise DirectWriteError(
                    f"Move target layer {target_name!r} does not exist after layer edits."
                )

        # Strings referenced by final layers and added/updated entities must be
        # registered before serializing the STRINGS block.
        for name, _aci, _lt, _flags in output_layer_specs:
            ensure_string(name)
        # Pre-encode edited/new entities now, allowing them to append strings.
        encoded_updates: Dict[int, _EncodedEntity] = {}
        for entity_id, entity in updated_entities.items():
            encoded_updates[entity_id] = _encode_entity(
                entity, layer_name_to_idx, string_to_idx, strings
            )
        encoded_additions = [
            _encode_entity(entity, layer_name_to_idx, string_to_idx, strings)
            for entity in added_entities
        ]

        meta_block = _merge_metadata(meta_raw, metadata_updates)
        strings_block = (
            strings_raw if strings == original_strings else _serialize_string_pool(strings)
        )
        layer_structure_changed = bool(
            added_layers or renamed_layers or updated_layers or deleted_layers_set
        )
        if not layer_structure_changed:
            layers_block = bytes(mm_obj[header.off_layers : header.off_blocks])
        else:
            layers_block = b"".join(
                _pack_layer_record(
                    ensure_string(name),
                    color_aci,
                    linetype_idx,
                    flags,
                )
                for name, color_aci, linetype_idx, flags in output_layer_specs
            )

        # Output block offsets before ENTITIES are now known.
        off_meta = HEADER_SIZE
        off_strings = off_meta + len(meta_block)
        off_layers = off_strings + len(strings_block)
        off_blocks = off_layers + len(layers_block)
        off_entities = off_blocks + len(blocks_raw)

        out_fd, temp_output_path = tempfile.mkstemp(
            prefix=f".{source.name}.", suffix=".direct.tmp", dir=str(source.parent)
        )
        # Keep the temporary INDEX on the local system temp drive. For SNT files
        # opened from an SMB/NAS path this avoids writing the large INDEX block to
        # the network twice (once as a side file and again inside the final SNT).
        idx_fd, temp_index_path = tempfile.mkstemp(
            prefix=f".{source.name}.", suffix=".index.tmp"
        )

        output_count = 0
        entity_rel_offset = 0
        copied_count = 0
        moved_count = 0
        updated_count = 0
        global_xmin = math.inf
        global_ymin = math.inf
        global_xmax = -math.inf
        global_ymax = -math.inf

        def add_bbox(bbox: Tuple[float, float, float, float]) -> None:
            nonlocal global_xmin, global_ymin, global_xmax, global_ymax
            x0, y0, x1, y1 = [float(v) for v in bbox]
            if not all(math.isfinite(v) for v in (x0, y0, x1, y1)):
                x0 = y0 = x1 = y1 = 0.0
            if x0 > x1:
                x0, x1 = x1, x0
            if y0 > y1:
                y0, y1 = y1, y0
            global_xmin = min(global_xmin, x0)
            global_ymin = min(global_ymin, y0)
            global_xmax = max(global_xmax, x1)
            global_ymax = max(global_ymax, y1)

        try:
            with os.fdopen(out_fd, "w+b", buffering=1 << 20) as out, os.fdopen(
                idx_fd, "wb", buffering=1 << 20
            ) as idx_out:
                out.write(b"\x00" * HEADER_SIZE)
                out.write(meta_block)
                out.write(strings_block)
                out.write(layers_block)
                out.write(blocks_raw)
                if out.tell() != off_entities:
                    raise DirectWriteError("Internal offset error before ENTITIES block.")

                can_bulk_copy = bool(
                    (header.flags & FLAG_HAS_INDEX)
                    and not deleted_ids
                    and not encoded_updates
                    and not deleted_layers_set
                    and not recolored_layers
                    and all(
                        original_idx_to_output_idx.get(i) == i
                        for i in range(len(original_layers))
                    )
                    and (len(mm_obj) - header.off_index)
                    == header.entity_count * INDEX_SIZE
                )

                if can_bulk_copy:
                    # Add/rename/layer-update and header-only move fast path.
                    # The complete native entity block is copied in large chunks;
                    # only explicitly moved common headers are patched. Existing
                    # INDEX records remain valid because bodies, sizes, bboxes and
                    # relative offsets are unchanged.
                    cursor = header.off_entities
                    if moved_entities:
                        for entity_id in sorted(moved_entities):
                            idx_pos = header.off_index + entity_id * INDEX_SIZE
                            _eid, _x0, _y0, _x1, _y1, rel_off = struct.unpack_from(
                                INDEX_FMT, mm_obj, idx_pos
                            )
                            entity_pos = header.off_entities + int(rel_off)
                            if entity_pos < cursor or entity_pos + ENTITY_HDR_SIZE > header.off_index:
                                raise DirectWriteError(
                                    f"Move entity {entity_id} has invalid INDEX offset {rel_off}."
                                )
                            # Bulk-copy everything before this changed header.
                            chunk_pos = cursor
                            while chunk_pos < entity_pos:
                                chunk_end = min(entity_pos, chunk_pos + (8 << 20))
                                out.write(mm_obj[chunk_pos:chunk_end])
                                chunk_pos = chunk_end

                            fields = struct.unpack_from(ENTITY_HDR_FMT, mm_obj, entity_pos)
                            (
                                etype_raw,
                                _old_layer_idx,
                                cmode_raw,
                                cval,
                                lt_idx,
                                lineweight,
                                body_size,
                            ) = fields
                            body_off = entity_pos + ENTITY_HDR_SIZE
                            body_end = body_off + int(body_size)
                            if body_end > header.off_index:
                                raise DirectWriteError(
                                    f"Move entity {entity_id} body exceeds ENTITIES block."
                                )
                            target_name = moved_entities[entity_id]
                            target_idx = layer_name_to_idx[target_name]
                            out.write(
                                struct.pack(
                                    ENTITY_HDR_FMT,
                                    int(etype_raw),
                                    int(target_idx),
                                    int(cmode_raw),
                                    int(cval),
                                    int(lt_idx),
                                    int(lineweight),
                                    int(body_size),
                                )
                            )
                            # Body is preserved byte-for-byte.
                            body_cursor = body_off
                            while body_cursor < body_end:
                                body_chunk_end = min(body_end, body_cursor + (8 << 20))
                                out.write(mm_obj[body_cursor:body_chunk_end])
                                body_cursor = body_chunk_end
                            cursor = body_end
                            moved_count += 1

                    chunk_pos = cursor
                    while chunk_pos < header.off_index:
                        chunk_end = min(header.off_index, chunk_pos + (8 << 20))
                        out.write(mm_obj[chunk_pos:chunk_end])
                        chunk_pos = chunk_end

                    # Copy original INDEX records exactly; additions are appended below.
                    idx_pos = header.off_index
                    while idx_pos < len(mm_obj):
                        idx_end = min(len(mm_obj), idx_pos + (8 << 20))
                        idx_out.write(mm_obj[idx_pos:idx_end])
                        idx_pos = idx_end

                    output_count = header.entity_count
                    entity_rel_offset = header.off_index - header.off_entities
                    copied_count = header.entity_count - moved_count
                    global_xmin, global_ymin, global_xmax, global_ymax = header.bbox
                else:
                    pos = header.off_entities
                    for entity_id in range(header.entity_count):
                        if pos + ENTITY_HDR_SIZE > header.off_index:
                            raise DirectWriteError(
                                f"Entity {entity_id} header exceeds the source ENTITIES block."
                            )
                        fields = struct.unpack_from(ENTITY_HDR_FMT, mm_obj, pos)
                        (
                            etype_raw,
                            old_layer_idx,
                            cmode_raw,
                            cval,
                            lt_idx,
                            lineweight,
                            body_size,
                        ) = fields
                        body_off = pos + ENTITY_HDR_SIZE
                        body_end = body_off + int(body_size)
                        if body_end > header.off_index:
                            raise DirectWriteError(
                                f"Entity {entity_id} body exceeds the source ENTITIES block."
                            )

                        if entity_id in deleted_ids:
                            pos = body_end
                            continue

                        if entity_id in encoded_updates:
                            encoded = encoded_updates[entity_id]
                            record = encoded.record
                            bbox = encoded.bbox
                            updated_count += 1
                        else:
                            try:
                                etype = EntityType(int(etype_raw))
                            except ValueError:
                                etype = EntityType.UNKNOWN
                            body = bytes(mm_obj[body_off:body_end])
                            original_bbox = _read_index_bbox(mm_obj, header, entity_id)
                            bbox = original_bbox or _bbox_from_body(etype, body)

                            source_layer_name = (
                                original_names[int(old_layer_idx)]
                                if 0 <= int(old_layer_idx) < len(original_names)
                                else f"<layer:{old_layer_idx}>"
                            )
                            target_layer_name = moved_entities.get(entity_id)
                            if target_layer_name is not None:
                                final_layer_name = target_layer_name
                                new_layer_idx = layer_name_to_idx[target_layer_name]
                                moved_count += 1
                            else:
                                if int(old_layer_idx) not in original_idx_to_output_idx:
                                    raise DirectWriteError(
                                        f"Entity {entity_id} remains on deleted layer {source_layer_name!r}; "
                                        "delete or move it in the same direct_write call."
                                    )
                                new_layer_idx = original_idx_to_output_idx[int(old_layer_idx)]
                                final_layer_name = renamed_layers.get(source_layer_name, source_layer_name)

                            new_cmode_raw = int(cmode_raw)
                            new_cval = int(cval)
                            recolor = recolored_layers.get(final_layer_name)
                            if recolor is None:
                                recolor = recolored_layers.get(source_layer_name)
                            if recolor is not None:
                                if len(recolor) < 3:
                                    raise DirectWriteError(
                                        f"Recolor for layer {final_layer_name!r} needs RGB values."
                                    )
                                rv = [float(recolor[0]), float(recolor[1]), float(recolor[2])]
                                if max(abs(v) for v in rv) <= 1.0:
                                    rv = [v * 255.0 for v in rv]
                                rr, gg, bb = [max(0, min(255, int(round(v)))) for v in rv]
                                new_cmode_raw = int(ColorMode.RGB)
                                new_cval = (rr << 16) | (gg << 8) | bb

                            header_unchanged = (
                                new_layer_idx == int(old_layer_idx)
                                and not deleted_layers_set
                                and new_cmode_raw == int(cmode_raw)
                                and new_cval == int(cval)
                            )
                            if header_unchanged:
                                record = bytes(mm_obj[pos:body_end])
                                copied_count += 1
                            else:
                                new_header = struct.pack(
                                    ENTITY_HDR_FMT,
                                    int(etype_raw),
                                    int(new_layer_idx),
                                    new_cmode_raw,
                                    new_cval,
                                    int(lt_idx),
                                    int(lineweight),
                                    int(body_size),
                                )
                                record = new_header + body

                        out.write(record)
                        idx_out.write(
                            struct.pack(
                                INDEX_FMT,
                                output_count,
                                float(bbox[0]),
                                float(bbox[1]),
                                float(bbox[2]),
                                float(bbox[3]),
                                entity_rel_offset,
                            )
                        )
                        add_bbox(bbox)
                        entity_rel_offset += len(record)
                        output_count += 1
                        pos = body_end

                    if pos > header.off_index:
                        raise DirectWriteError("Source entity scan crossed into INDEX block.")

                for encoded in encoded_additions:
                    out.write(encoded.record)
                    bbox = encoded.bbox
                    idx_out.write(
                        struct.pack(
                            INDEX_FMT,
                            output_count,
                            float(bbox[0]),
                            float(bbox[1]),
                            float(bbox[2]),
                            float(bbox[3]),
                            entity_rel_offset,
                        )
                    )
                    add_bbox(bbox)
                    entity_rel_offset += len(encoded.record)
                    output_count += 1

                idx_out.flush()
                os.fsync(idx_out.fileno())
                off_index = out.tell()
                with open(temp_index_path, "rb", buffering=1 << 20) as idx_in:
                    shutil.copyfileobj(idx_in, out, length=1 << 20)

                if output_count == 0:
                    bbox_out = (0.0, 0.0, 0.0, 0.0)
                else:
                    bbox_out = (global_xmin, global_ymin, global_xmax, global_ymax)

                flags_out = int(header.flags) | FLAG_HAS_INDEX
                header_raw = struct.pack(
                    HEADER_FMT,
                    header.magic,
                    header.version_major,
                    header.version_minor,
                    flags_out,
                    output_count,
                    *bbox_out,
                    off_meta,
                    off_strings,
                    off_layers,
                    off_blocks,
                    off_entities,
                    off_index,
                    0,
                    header.reserved,
                )
                crc = zlib.crc32(header_raw[:HEADER_CRC_OFFSET]) & 0xFFFF_FFFF
                header_raw = (
                    header_raw[:HEADER_CRC_OFFSET]
                    + struct.pack("<I", crc)
                    + header_raw[HEADER_CRC_END:]
                )
                out.seek(0)
                out.write(header_raw)
                out.flush()
                os.fsync(out.fileno())

            temp_output = Path(temp_output_path)
            if validate:
                # Quick validation is O(1): reader header/CRC/offset checks, META,
                # layer table, exact INDEX size, and first/last entity bounds.
                # Use validate="full" in regression tests to scan every body.
                with SntReader(temp_output) as verify_reader:
                    if int(verify_reader.entity_count) != output_count:
                        raise DirectWriteError(
                            f"Validation count mismatch: header={output_count}, "
                            f"reader={verify_reader.entity_count}."
                        )
                    _ = verify_reader.meta
                    _ = verify_reader.layers

                with open(temp_output, "rb") as verify_file, mmap.mmap(
                    verify_file.fileno(), 0, access=mmap.ACCESS_READ
                ) as verify_mm:
                    verify_header = _parse_header(verify_mm)
                    expected_index_bytes = output_count * INDEX_SIZE
                    actual_index_bytes = len(verify_mm) - verify_header.off_index
                    if actual_index_bytes != expected_index_bytes:
                        raise DirectWriteError(
                            f"Validation INDEX size mismatch: expected {expected_index_bytes}, "
                            f"got {actual_index_bytes}."
                        )
                    if output_count:
                        for check_id in (0, output_count - 1):
                            idx_pos = verify_header.off_index + check_id * INDEX_SIZE
                            _eid, _x0, _y0, _x1, _y1, rel_off = struct.unpack_from(
                                INDEX_FMT, verify_mm, idx_pos
                            )
                            entity_pos = verify_header.off_entities + int(rel_off)
                            if entity_pos + ENTITY_HDR_SIZE > verify_header.off_index:
                                raise DirectWriteError(
                                    f"Validation entity {check_id} header exceeds ENTITIES block."
                                )
                            fields = struct.unpack_from(ENTITY_HDR_FMT, verify_mm, entity_pos)
                            body_size = int(fields[-1])
                            if entity_pos + ENTITY_HDR_SIZE + body_size > verify_header.off_index:
                                raise DirectWriteError(
                                    f"Validation entity {check_id} body exceeds ENTITIES block."
                                )

                if str(validate).lower() == "full":
                    with SntReader(temp_output) as verify_reader:
                        verified = 0
                        for verify_hdr in verify_reader.iter_entities():
                            verify_reader.read_body(verify_hdr)
                            verified += 1
                        if verified != output_count:
                            raise DirectWriteError(
                                f"Full validation mismatch: expected {output_count}, got {verified}."
                            )

            # Windows does not allow replacing a file while it is still memory
            # mapped/open. Close the source handles explicitly before the atomic
            # replacement; the surrounding context managers tolerate this.
            mm_obj.close()
            src_file.close()
            os.replace(temp_output, source)
            temp_output_path = None
            output_size = source.stat().st_size
            return DirectWriteResult(
                snt_path=source,
                original_entity_count=header.entity_count,
                entity_count=output_count,
                added_count=len(encoded_additions),
                deleted_count=len(deleted_ids),
                updated_count=updated_count,
                moved_count=moved_count,
                layer_count=len(output_layer_specs),
                source_size_bytes=source_size,
                output_size_bytes=output_size,
                unchanged_records_copied=copied_count,
            )
        finally:
            if temp_output_path:
                try:
                    os.unlink(temp_output_path)
                except OSError:
                    pass
            if temp_index_path:
                try:
                    os.unlink(temp_index_path)
                except OSError:
                    pass
